//Static javascript file which will be imported to html files
