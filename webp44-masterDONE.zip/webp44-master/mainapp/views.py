from django.shortcuts import render
from django.http import HttpResponse, Http404

appname = 'DatingApp'

# Create your views here.
def index(request):
    # return HttpResponse("HOT MEMES!")
    context = { 'appname': appname }
    return render(request,'mainapp/index.html',context)

def signup(request):
    context = { 'appname': appname }
    return render(request,'mainapp/createAccount.html',context)

def login(request):
    context = { 'appname': appname }
    return render(request,'mainapp/friends.html',context)

def membersProfile(request):
    context = { 'appname': appname }
    return render(request,'mainapp/member.html',context)

def userProfile(request):
    context = { 'appname': appname }
    return render(request,'mainapp/profile.html',context)

def logout(request):
    context = { 'appname': appname }
    return render(request,'mainapp/logOut.html',context)
